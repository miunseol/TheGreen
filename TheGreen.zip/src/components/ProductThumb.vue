<template>
  <section>
    <div>
      <img src="https://github.com/miunseol/TheGreen/blob/sub/src/assets/image/productImg/%EC%84%B8%EB%A0%A8%EB%90%9C%20%EC%97%90%EC%BD%94%ED%8C%A9%20%EB%B8%94%EB%9E%99.png?raw=true" alt="#">
      <p>세련된 에코팩 블랙</p>
    </div>
    <div>
      <img src="https://github.com/miunseol/TheGreen/blob/sub/src/assets/image/productImg/%EC%86%8D%EC%82%B4%EA%B9%8C%EC%A7%80%20%ED%8E%B8%EC%95%88%ED%95%9C%20%EB%A7%88%EC%9D%B4%20%ED%9B%84%EB%93%9C.png?raw=true" alt="#">
      <p>속살까지 편안한 마이 후드</p>
    </div>
    <div>
      <img src="https://github.com/miunseol/TheGreen/blob/sub/src/assets/image/productImg/%EC%B4%89%EC%B4%89%ED%95%9C%20%EB%B3%B4%EC%8A%B5%EC%9D%B4%20%ED%95%84%EC%9A%94%ED%95%B4.png?raw=true" alt="#">
      <p>촉촉한 보습이 필요해</p>
    </div>
  </section>
</template>

<script>
export default {

}
</script>

<style scoped>
  div{
    width: 380px;
    height: 100%;
  }
  section{
    
    width: 1200px;
    display: flex;
    justify-content: space-between;
  }
  img{
    display: block;
    width: 380px;
    height: 315px;
    background-color: #333;
  }
  p{
    width: 380px;
    height: 45px;
    background-color: #eaeaea;
    text-align: center;
    padding: 8px;
  }
</style>