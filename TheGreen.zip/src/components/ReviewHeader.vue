<template>
  <div>
    <review-view />
  </div>
</template>

<script>
import ReviewView from "@/views/ReviewView.vue";

export default {
  components: { ReviewView },
};
</script>

<style></style>
