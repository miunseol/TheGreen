<template>
  <footer class="">
    <div class="container row py-5 mx-auto">
      <div class="col-4">
      <h5>The Green</h5>
      <p>
        921, Jungang-daero, Danwon-gu, Ansan-si, Gyeonggi-do, Republic of Korea
        15361
      </p>
      <p>2023 Green. All rights reserved</p>
    </div>
    <div class="col-2">
      <h5>Links</h5>
      <ul class="list-unstyled">
        <li><a href="">Home</a></li>
        <li><a href="">Shopping</a></li>
        <li><a href="">My Cart</a></li>
        <li><a href="">Customer Center</a></li>
      </ul>
    </div>
    <div class="col-2">
      <h5>Help</h5>
      <ul class="list-unstyled">
        <li><a href="">Payment Options</a></li>
        <li><a href="">Returns</a></li>
        <li><a href="">Privacy Policies</a></li>
      </ul>
    </div>
    <div class="col-2">
      <h5>SNS</h5>
      <ul class="list-unstyled">
        <li><a href="">Kakao Talk</a></li>
        <li><a href="">Instagram</a></li>
        <li><a href="">Twitter</a></li>
      </ul>
    </div>
    </div>

  </footer>
</template>

<style scoped>
footer {
  background-color: #f8f9fa;
}
</style>
